#pragma once

#include "Lpf2/Local/IO/IO.hpp"
#include "Lpf2/Local/IO/UART.hpp"
#include <Arduino.h>
#include <HardwareSerial.h>

class Esp32IO : public Lpf2::Local::IO
{
public:
    explicit Esp32IO(int uart_num);

    bool init();
    void beginUart(uint32_t baud, uint32_t config, int rx, int tx);
    
    // Required by IO
    Lpf2::Local::Uart *getUart() override;
    Lpf2::Local::PWM *getPWM() override { return &pwm_; }
    bool ready() const override { return true; }              // Always ready

private:
    class DummyPwm : public Lpf2::Local::PWM
    {
    public:
        void out(uint8_t, uint8_t) override {}
    };

    class Esp32s3Uart : public Lpf2::Local::Uart
    {
    public:
        explicit Esp32s3Uart(int uart_num);

        // UART control
        void end() override;
        void setBaudrate(uint32_t baudrate) override;

        // Data I/O
        size_t write(const uint8_t *data, size_t len) override;
        int read() override;
        size_t read(uint8_t *data, size_t len) override;
        int available() override;
        void flush() override;

        // Required by abstract base
        void discardRxFiFo() override;
        void setUartPinsState(bool highZ) override;
        float readCh(uint8_t ch) override;
        void writeCh(uint8_t ch, bool state) override;

        // Helper
        void begin(uint32_t baudrate, uint32_t config, int rx_pin, int tx_pin);

    private:
        HardwareSerial serial_;
        uint32_t baud_ = 115200;
        uint32_t config_ = SERIAL_8N1;
        int rx_pin_ = -1;
        int tx_pin_ = -1;
    };

    DummyPwm pwm_;
    Esp32s3Uart uart_;
};
