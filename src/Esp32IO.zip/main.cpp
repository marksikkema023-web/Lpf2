/**
 *  Copyright (C) 2026 - Rbel12b
 * 
 *  This program is free software: you can redistribute it and/or modify
 *  it under the terms of the GNU Affero General Public License as
 *  published by the Free Software Foundation, either version 3 of the
 *  License, or (at your option) any later version.
 *
 *  This program is distributed in the hope that it will be useful,
 *  but WITHOUT ANY WARRANTY; without even the implied warranty of
 *  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *  GNU Affero General Public License for more details.
 *
 *  You should have received a copy of the GNU Affero General Public License
 *  along with this program.  If not, see <https://www.gnu.org/licenses/>.
 *  */

#include <Arduino.h>
#include "Lpf2/HubEmulation.hpp"
#include "Lpf2/DeviceDescLib.hpp"
#include "Lpf2/DeviceFactory.hpp"

#include "Esp32IO.hpp"
//#include "Lpf2/Local/IO/UART.hpp"
//#include "Lpf2/Local/IO/IO.hpp"
#include "Lpf2/Local/Port.hpp"

#include "driver/mcpwm.h"
/*
On ESP32‑C3/S3, the correct drivers are?:
driver/mcpwm_prelude.h (new MCPWM v2)
driver/ledc.h (simple PWM)
driver/timer_group.h (timers)
*/
Lpf2::HubEmulation hub("XIAO S3 Hub", Lpf2::HubType::CONTROL_PLUS_HUB);

#define USE_LOCAL_PORT 1
#ifdef USE_LOCAL_PORT
//#include "../LocalPort/device.hpp"
//#include "Lpf2/Local/Port.hpp"
Esp32IO io(1);
Lpf2::Local::Port portA(io);
#endif

void setup()
{
    Serial.begin(981200);

    io.beginUart(2400, SERIAL_8N1, 7, 6);  // RX=7, TX=6
    io.init();
    portA.init();

    Lpf2::DeviceRegistry::registerDefault();
    Lpf2::DeviceDescRegistry::registerDefault();
    hub.setUseBuiltInDevices(true);
    hub.start();
    hub.setBatteryLevel(30);

#ifdef USE_LOCAL_PORT
//    io.init(15, 16, 21, 10);
//    port.init();
//    hub.attachPort(Lpf2::PortNum(Lpf2::ControlPlusHubPort::A), &port);
#endif

    hub.attachPort(Lpf2::PortNum(Lpf2::ControlPlusHubPort::A), &portA);
    Serial.println("LPF2 sensor port ready on D6/D7");
}

void loop()
{
    vTaskDelay(1);

    if (Serial.available()) {
        uint8_t c = Serial.read();
        if (c == 0x03) {
            // Ctrl+C received
            ESP.restart();
        }
    }

    // Update the port (handles UART protocol)
    portA.update();
#ifdef USE_LOCAL_PORT
//    port.update();
#endif
}