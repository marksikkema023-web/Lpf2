#include "Esp32IO.hpp"

// ----------------------
// Esp32IO
// ----------------------

Esp32IO::Esp32IO(int uart_num)
    : uart_(uart_num)
{
}

bool Esp32IO::init()
{
    return true; // UART-only
}

void Esp32IO::beginUart(uint32_t baud, uint32_t config, int rx, int tx)
{
    uart_.begin(baud, config, rx, tx);
}

Lpf2::Local::Uart *Esp32IO::getUart()
{
    return &uart_;
}

// ----------------------
// Esp32s3Uart
// ----------------------

Esp32IO::Esp32s3Uart::Esp32s3Uart(int uart_num)
    : serial_(uart_num)
{
}

void Esp32IO::Esp32s3Uart::begin(uint32_t baudrate,
                                 uint32_t config,
                                 int rx_pin,
                                 int tx_pin)
{
    baud_ = baudrate;
    config_ = config;
    rx_pin_ = rx_pin;
    tx_pin_ = tx_pin;

    serial_.begin(baudrate, config, rx_pin, tx_pin);
}

void Esp32IO::Esp32s3Uart::end()
{
    serial_.end();
}

void Esp32IO::Esp32s3Uart::setBaudrate(uint32_t baudrate)
{
    baud_ = baudrate;
    serial_.updateBaudRate(baudrate);
}

size_t Esp32IO::Esp32s3Uart::write(const uint8_t *data, size_t len)
{
    return serial_.write(data, len);
}

int Esp32IO::Esp32s3Uart::read()
{
    return serial_.read();
}

size_t Esp32IO::Esp32s3Uart::read(uint8_t *data, size_t len)
{
    return serial_.readBytes(data, len);
}

int Esp32IO::Esp32s3Uart::available()
{
    return serial_.available();
}

void Esp32IO::Esp32s3Uart::flush()
{
    serial_.flush();
}

void Esp32IO::Esp32s3Uart::discardRxFiFo()
{
    while (serial_.available())
        serial_.read();
}

void Esp32IO::Esp32s3Uart::setUartPinsState(bool highZ)
{
    if (highZ)
    {
        serial_.end();
        if (rx_pin_ >= 0) pinMode(rx_pin_, INPUT);
        if (tx_pin_ >= 0) pinMode(tx_pin_, INPUT);
    }
    else
    {
        serial_.begin(baud_, config_, rx_pin_, tx_pin_);
    }
}

float Esp32IO::Esp32s3Uart::readCh(uint8_t ch)
{
/*    int pin = (ch == 0) ? rx_pin_ : tx_pin_;
    if (pin < 0) return 0.0f;

    int raw = analogRead(pin);
    return (float)raw * (3.3f / 4095.0f);*/
    return 3.3f;
}

void Esp32IO::Esp32s3Uart::writeCh(uint8_t ch, bool state)
{
/*    int pin = (ch == 0) ? rx_pin_ : tx_pin_;
    if (pin < 0) return;

    pinMode(pin, OUTPUT);
    digitalWrite(pin, state ? HIGH : LOW);*/
}
